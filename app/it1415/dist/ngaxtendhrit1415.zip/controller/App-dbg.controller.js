sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("nga.xtendhr.it1415.controller.App", {
      onInit() {
      }
  });
});