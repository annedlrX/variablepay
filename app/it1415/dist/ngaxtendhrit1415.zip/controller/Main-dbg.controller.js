sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("nga.xtendhr.it1415.controller.Main", {
        onInit() {
        }
    });
});